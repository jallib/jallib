using Microsoft.Win32.SafeHandles;
using System.Threading;
using System.Runtime.InteropServices; 

///<summary>
/// Project: GenericHid
/// 
/// Based on V4.51

using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace GenericHid
{
    internal class FrmMain 
        
        : System.Windows.Forms.Form 
    {

        private Thread rxThread = null;
        private PictureBox devicePresentPB;
        private Bitmap ledRedBmp;
        private Bitmap ledGreenBmp;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private GroupBox ctrlInputGroupBox;
        private GroupBox groupBox2;
        private Bitmap ledNoneBmp;

        #region '"Windows Form Designer generated code "' 
        public FrmMain() : base() 
        {
            ledRedBmp = new Bitmap(GetType(), "LedRed.ico");
            ledGreenBmp = new Bitmap(GetType(), "LedGreen.ico");
            ledNoneBmp = new Bitmap(GetType(), "LedNone.ico");

            // This call is required by the Windows Form Designer.
            InitializeComponent(); 



        } 
        // Form overrides dispose to clean up the component list.
        protected override void Dispose( bool Disposing ) 
        { 
            if ( Disposing ) 
            { 
                if ( !( components == null ) ) 
                { 
                    components.Dispose(); 
                } 
            } 
            base.Dispose( Disposing ); 
        } 
        
        // Required by the Windows Form Designer
        private System.ComponentModel.IContainer components; 
        public System.Windows.Forms.ToolTip ToolTip1;
        // NOTE: The following procedure is required by the Windows Form Designer
        // It can be modified using the Windows Form Designer.
        // Do not modify it using the code editor.
        internal System.Windows.Forms.GroupBox fraDeviceIdentifiers; 
        internal System.Windows.Forms.Label lblVendorID; 
        internal System.Windows.Forms.TextBox txtVendorID; 
        internal System.Windows.Forms.Label lblProductID; 
        internal System.Windows.Forms.TextBox txtProductID;
        private ProgressBar adcIndicator;
        private CheckBox adcOnCheckBox;
        private CheckBox led0CheckBox;
        private CheckBox led1CheckBox;
        private CheckBox led2CheckBox;
        private CheckBox led3CheckBox;
        private CheckBox led4CheckBox;
        private CheckBox led5CheckBox;
        private CheckBox led6CheckBox;
        private CheckBox led7CheckBox;
        private Label portATextBox;
        private Label portBTextBox;
        private Label portCTextBox;
        private Label portDTextBox; 
        internal System.Windows.Forms.Button cmdFindDevice; 
       
        [ System.Diagnostics.DebuggerStepThrough() ]
        private void InitializeComponent() 
        {
            this.components = new System.ComponentModel.Container();
            this.ToolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.fraDeviceIdentifiers = new System.Windows.Forms.GroupBox();
            this.devicePresentPB = new System.Windows.Forms.PictureBox();
            this.txtProductID = new System.Windows.Forms.TextBox();
            this.cmdFindDevice = new System.Windows.Forms.Button();
            this.lblProductID = new System.Windows.Forms.Label();
            this.txtVendorID = new System.Windows.Forms.TextBox();
            this.lblVendorID = new System.Windows.Forms.Label();
            this.adcIndicator = new System.Windows.Forms.ProgressBar();
            this.adcOnCheckBox = new System.Windows.Forms.CheckBox();
            this.led0CheckBox = new System.Windows.Forms.CheckBox();
            this.led1CheckBox = new System.Windows.Forms.CheckBox();
            this.led2CheckBox = new System.Windows.Forms.CheckBox();
            this.led3CheckBox = new System.Windows.Forms.CheckBox();
            this.led4CheckBox = new System.Windows.Forms.CheckBox();
            this.led5CheckBox = new System.Windows.Forms.CheckBox();
            this.led6CheckBox = new System.Windows.Forms.CheckBox();
            this.led7CheckBox = new System.Windows.Forms.CheckBox();
            this.portATextBox = new System.Windows.Forms.Label();
            this.portBTextBox = new System.Windows.Forms.Label();
            this.portCTextBox = new System.Windows.Forms.Label();
            this.portDTextBox = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.ctrlInputGroupBox = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.fraDeviceIdentifiers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.devicePresentPB)).BeginInit();
            this.ctrlInputGroupBox.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // fraDeviceIdentifiers
            // 
            this.fraDeviceIdentifiers.Controls.Add(this.devicePresentPB);
            this.fraDeviceIdentifiers.Controls.Add(this.txtProductID);
            this.fraDeviceIdentifiers.Controls.Add(this.cmdFindDevice);
            this.fraDeviceIdentifiers.Controls.Add(this.lblProductID);
            this.fraDeviceIdentifiers.Controls.Add(this.txtVendorID);
            this.fraDeviceIdentifiers.Controls.Add(this.lblVendorID);
            this.fraDeviceIdentifiers.Location = new System.Drawing.Point(16, 16);
            this.fraDeviceIdentifiers.Name = "fraDeviceIdentifiers";
            this.fraDeviceIdentifiers.Size = new System.Drawing.Size(372, 139);
            this.fraDeviceIdentifiers.TabIndex = 10;
            this.fraDeviceIdentifiers.TabStop = false;
            this.fraDeviceIdentifiers.Text = "Device Identifiers";
            // 
            // devicePresentPB
            // 
            this.devicePresentPB.BackgroundImage = global::GenericHid.Properties.Resources.LedNone;
            this.devicePresentPB.Location = new System.Drawing.Point(176, 97);
            this.devicePresentPB.Name = "devicePresentPB";
            this.devicePresentPB.Size = new System.Drawing.Size(16, 16);
            this.devicePresentPB.TabIndex = 28;
            this.devicePresentPB.TabStop = false;
            this.devicePresentPB.Click += new System.EventHandler(this.devicePresentPB_Click);
            // 
            // txtProductID
            // 
            this.txtProductID.Location = new System.Drawing.Point(120, 56);
            this.txtProductID.Name = "txtProductID";
            this.txtProductID.Size = new System.Drawing.Size(72, 20);
            this.txtProductID.TabIndex = 3;
            this.txtProductID.Text = "1299";
            this.txtProductID.TextChanged += new System.EventHandler(this.txtProductID_TextChanged);
            // 
            // cmdFindDevice
            // 
            this.cmdFindDevice.Location = new System.Drawing.Point(19, 97);
            this.cmdFindDevice.Name = "cmdFindDevice";
            this.cmdFindDevice.Size = new System.Drawing.Size(94, 26);
            this.cmdFindDevice.TabIndex = 11;
            this.cmdFindDevice.Text = "Find My Device";
            this.cmdFindDevice.Click += new System.EventHandler(this.cmdFindDevice_Click);
            // 
            // lblProductID
            // 
            this.lblProductID.Location = new System.Drawing.Point(16, 56);
            this.lblProductID.Name = "lblProductID";
            this.lblProductID.Size = new System.Drawing.Size(112, 23);
            this.lblProductID.TabIndex = 2;
            this.lblProductID.Text = "Product ID (hex):";
            // 
            // txtVendorID
            // 
            this.txtVendorID.Location = new System.Drawing.Point(120, 24);
            this.txtVendorID.Name = "txtVendorID";
            this.txtVendorID.Size = new System.Drawing.Size(72, 20);
            this.txtVendorID.TabIndex = 1;
            this.txtVendorID.Text = "0925";
            this.txtVendorID.TextChanged += new System.EventHandler(this.txtVendorID_TextChanged);
            // 
            // lblVendorID
            // 
            this.lblVendorID.Location = new System.Drawing.Point(16, 24);
            this.lblVendorID.Name = "lblVendorID";
            this.lblVendorID.Size = new System.Drawing.Size(112, 23);
            this.lblVendorID.TabIndex = 0;
            this.lblVendorID.Text = "Vendor ID (hex):";
            // 
            // adcIndicator
            // 
            this.adcIndicator.Location = new System.Drawing.Point(176, 101);
            this.adcIndicator.Maximum = 1023;
            this.adcIndicator.Name = "adcIndicator";
            this.adcIndicator.Size = new System.Drawing.Size(442, 23);
            this.adcIndicator.Step = 1;
            this.adcIndicator.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.adcIndicator.TabIndex = 13;
            this.adcIndicator.Click += new System.EventHandler(this.adcIndicator_Click);
            // 
            // adcOnCheckBox
            // 
            this.adcOnCheckBox.AutoSize = true;
            this.adcOnCheckBox.Location = new System.Drawing.Point(147, 22);
            this.adcOnCheckBox.Name = "adcOnCheckBox";
            this.adcOnCheckBox.Size = new System.Drawing.Size(65, 18);
            this.adcOnCheckBox.TabIndex = 14;
            this.adcOnCheckBox.Text = "ADC On";
            this.adcOnCheckBox.UseVisualStyleBackColor = true;
            this.adcOnCheckBox.CheckedChanged += new System.EventHandler(this.adcOnCheckBox_CheckedChanged);
            // 
            // led0CheckBox
            // 
            this.led0CheckBox.AutoSize = true;
            this.led0CheckBox.Location = new System.Drawing.Point(18, 22);
            this.led0CheckBox.Name = "led0CheckBox";
            this.led0CheckBox.Size = new System.Drawing.Size(54, 18);
            this.led0CheckBox.TabIndex = 15;
            this.led0CheckBox.Text = "LED 0";
            this.led0CheckBox.UseVisualStyleBackColor = true;
            this.led0CheckBox.CheckedChanged += new System.EventHandler(this.ledCheckBox_CheckedChanged);
            // 
            // led1CheckBox
            // 
            this.led1CheckBox.AutoSize = true;
            this.led1CheckBox.Location = new System.Drawing.Point(18, 45);
            this.led1CheckBox.Name = "led1CheckBox";
            this.led1CheckBox.Size = new System.Drawing.Size(54, 18);
            this.led1CheckBox.TabIndex = 16;
            this.led1CheckBox.Text = "LED 1";
            this.led1CheckBox.UseVisualStyleBackColor = true;
            this.led1CheckBox.CheckedChanged += new System.EventHandler(this.ledCheckBox_CheckedChanged);
            // 
            // led2CheckBox
            // 
            this.led2CheckBox.AutoSize = true;
            this.led2CheckBox.Location = new System.Drawing.Point(18, 69);
            this.led2CheckBox.Name = "led2CheckBox";
            this.led2CheckBox.Size = new System.Drawing.Size(54, 18);
            this.led2CheckBox.TabIndex = 17;
            this.led2CheckBox.Text = "LED 2";
            this.led2CheckBox.UseVisualStyleBackColor = true;
            this.led2CheckBox.CheckedChanged += new System.EventHandler(this.ledCheckBox_CheckedChanged);
            // 
            // led3CheckBox
            // 
            this.led3CheckBox.AutoSize = true;
            this.led3CheckBox.Location = new System.Drawing.Point(18, 93);
            this.led3CheckBox.Name = "led3CheckBox";
            this.led3CheckBox.Size = new System.Drawing.Size(54, 18);
            this.led3CheckBox.TabIndex = 18;
            this.led3CheckBox.Text = "LED 3";
            this.led3CheckBox.UseVisualStyleBackColor = true;
            this.led3CheckBox.CheckedChanged += new System.EventHandler(this.ledCheckBox_CheckedChanged);
            // 
            // led4CheckBox
            // 
            this.led4CheckBox.AutoSize = true;
            this.led4CheckBox.Location = new System.Drawing.Point(87, 22);
            this.led4CheckBox.Name = "led4CheckBox";
            this.led4CheckBox.Size = new System.Drawing.Size(54, 18);
            this.led4CheckBox.TabIndex = 19;
            this.led4CheckBox.Text = "LED 4";
            this.led4CheckBox.UseVisualStyleBackColor = true;
            this.led4CheckBox.CheckedChanged += new System.EventHandler(this.ledCheckBox_CheckedChanged);
            // 
            // led5CheckBox
            // 
            this.led5CheckBox.AutoSize = true;
            this.led5CheckBox.Location = new System.Drawing.Point(87, 45);
            this.led5CheckBox.Name = "led5CheckBox";
            this.led5CheckBox.Size = new System.Drawing.Size(54, 18);
            this.led5CheckBox.TabIndex = 20;
            this.led5CheckBox.Text = "LED 5";
            this.led5CheckBox.UseVisualStyleBackColor = true;
            this.led5CheckBox.CheckedChanged += new System.EventHandler(this.ledCheckBox_CheckedChanged);
            // 
            // led6CheckBox
            // 
            this.led6CheckBox.AutoSize = true;
            this.led6CheckBox.Location = new System.Drawing.Point(87, 69);
            this.led6CheckBox.Name = "led6CheckBox";
            this.led6CheckBox.Size = new System.Drawing.Size(54, 18);
            this.led6CheckBox.TabIndex = 21;
            this.led6CheckBox.Text = "LED 6";
            this.led6CheckBox.UseVisualStyleBackColor = true;
            this.led6CheckBox.CheckedChanged += new System.EventHandler(this.ledCheckBox_CheckedChanged);
            // 
            // led7CheckBox
            // 
            this.led7CheckBox.AutoSize = true;
            this.led7CheckBox.Location = new System.Drawing.Point(87, 93);
            this.led7CheckBox.Name = "led7CheckBox";
            this.led7CheckBox.Size = new System.Drawing.Size(54, 18);
            this.led7CheckBox.TabIndex = 22;
            this.led7CheckBox.Text = "LED 7";
            this.led7CheckBox.UseVisualStyleBackColor = true;
            this.led7CheckBox.CheckedChanged += new System.EventHandler(this.ledCheckBox_CheckedChanged);
            // 
            // portATextBox
            // 
            this.portATextBox.AutoSize = true;
            this.portATextBox.Location = new System.Drawing.Point(76, 35);
            this.portATextBox.Name = "portATextBox";
            this.portATextBox.Size = new System.Drawing.Size(34, 14);
            this.portATextBox.TabIndex = 23;
            this.portATextBox.Text = "portA";
            // 
            // portBTextBox
            // 
            this.portBTextBox.AutoSize = true;
            this.portBTextBox.Location = new System.Drawing.Point(76, 60);
            this.portBTextBox.Name = "portBTextBox";
            this.portBTextBox.Size = new System.Drawing.Size(34, 14);
            this.portBTextBox.TabIndex = 24;
            this.portBTextBox.Text = "portA";
            // 
            // portCTextBox
            // 
            this.portCTextBox.AutoSize = true;
            this.portCTextBox.Location = new System.Drawing.Point(76, 85);
            this.portCTextBox.Name = "portCTextBox";
            this.portCTextBox.Size = new System.Drawing.Size(34, 14);
            this.portCTextBox.TabIndex = 25;
            this.portCTextBox.Text = "portA";
            // 
            // portDTextBox
            // 
            this.portDTextBox.AutoSize = true;
            this.portDTextBox.Location = new System.Drawing.Point(76, 110);
            this.portDTextBox.Name = "portDTextBox";
            this.portDTextBox.Size = new System.Drawing.Size(34, 14);
            this.portDTextBox.TabIndex = 26;
            this.portDTextBox.Text = "portA";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 14);
            this.label1.TabIndex = 27;
            this.label1.Text = "Port A";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 14);
            this.label2.TabIndex = 28;
            this.label2.Text = "Port B";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 88);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 14);
            this.label3.TabIndex = 29;
            this.label3.Text = "Port C";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 113);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 14);
            this.label4.TabIndex = 30;
            this.label4.Text = "Port D";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(173, 74);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 14);
            this.label5.TabIndex = 31;
            this.label5.Text = "ADC";
            // 
            // ctrlInputGroupBox
            // 
            this.ctrlInputGroupBox.Controls.Add(this.led7CheckBox);
            this.ctrlInputGroupBox.Controls.Add(this.led6CheckBox);
            this.ctrlInputGroupBox.Controls.Add(this.led5CheckBox);
            this.ctrlInputGroupBox.Controls.Add(this.led4CheckBox);
            this.ctrlInputGroupBox.Controls.Add(this.led3CheckBox);
            this.ctrlInputGroupBox.Controls.Add(this.led2CheckBox);
            this.ctrlInputGroupBox.Controls.Add(this.led1CheckBox);
            this.ctrlInputGroupBox.Controls.Add(this.led0CheckBox);
            this.ctrlInputGroupBox.Controls.Add(this.adcOnCheckBox);
            this.ctrlInputGroupBox.Location = new System.Drawing.Point(405, 20);
            this.ctrlInputGroupBox.Name = "ctrlInputGroupBox";
            this.ctrlInputGroupBox.Size = new System.Drawing.Size(244, 135);
            this.ctrlInputGroupBox.TabIndex = 32;
            this.ctrlInputGroupBox.TabStop = false;
            this.ctrlInputGroupBox.Text = "Control (input)";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.portBTextBox);
            this.groupBox2.Controls.Add(this.adcIndicator);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.portATextBox);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.portCTextBox);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.portDTextBox);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(16, 161);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(633, 150);
            this.groupBox2.TabIndex = 33;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Status (output)";
            // 
            // FrmMain
            // 
            this.ClientSize = new System.Drawing.Size(663, 332);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.ctrlInputGroupBox);
            this.Controls.Add(this.fraDeviceIdentifiers);
            this.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Location = new System.Drawing.Point(21, 28);
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Generic HID Tester";
            this.Closed += new System.EventHandler(this.frmMain_Closed);
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.fraDeviceIdentifiers.ResumeLayout(false);
            this.fraDeviceIdentifiers.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.devicePresentPB)).EndInit();
            this.ctrlInputGroupBox.ResumeLayout(false);
            this.ctrlInputGroupBox.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }         
        #endregion 
        
        private IntPtr deviceNotificationHandle; 
        private Boolean exclusiveAccess; 
        private SafeFileHandle hidHandle; 
        private String hidUsage; 
        private Boolean myDeviceDetected; 
        private String myDevicePathName; 
        private SafeFileHandle readHandle; 
        private SafeFileHandle writeHandle; 
        
        private Debugging MyDebugging = new Debugging(); //  For viewing results of API calls via Debug.Write.
        private DeviceManagement MyDeviceManagement = new DeviceManagement(); 
        private Hid MyHid = new Hid(); 
        
        internal FrmMain FrmMy; 
        
        ///  <summary>
        ///  Define a class of delegates that point to the Hid.ReportIn.Read function.
        ///  The delegate has the same parameters as Hid.ReportIn.Read.
        ///  Used for asynchronous reads from the device.       
        ///  </summary>
        
        private delegate void ReadInputReportDelegate( SafeFileHandle hidHandle, SafeFileHandle readHandle, SafeFileHandle writeHandle, ref Boolean myDeviceDetected, ref Byte[] readBuffer, ref Boolean success );
        
        //  This delegate has the same parameters as AccessForm.
        //  Used in accessing the application's form from a different thread.
        
        private delegate void MarshalToForm( String action, String textToAdd );


        internal void SetDeviceLed(bool bOnOff)
        {
            if (bOnOff)
            {
                devicePresentPB.BackgroundImage = ledGreenBmp;
            }
            else
            {
                devicePresentPB.BackgroundImage = ledNoneBmp;
            }

        }

        ///  <summary>
        ///  Called when a WM_DEVICECHANGE message has arrived,
        ///  indicating that a device has been attached or removed.
        ///  </summary>
        ///  
        ///  <param name="m"> a message with information about the device </param>
        
        internal void OnDeviceChange( Message m ) 
        {             
            Debug.WriteLine( "WM_DEVICECHANGE" ); 
            
            try 
            {
                if ((m.WParam.ToInt32() == DeviceManagement.DBT_DEVICEARRIVAL)) 
                { 
                    
                    //  If WParam contains DBT_DEVICEARRIVAL, a device has been attached.
                    
                    Debug.WriteLine( "A device has been attached." );

                    //  Find out if it's the device we're communicating with.
                    
                    
                }
                else if ((m.WParam.ToInt32() == DeviceManagement.DBT_DEVICEREMOVECOMPLETE)) 
                { 
                    
                    //  If WParam contains DBT_DEVICEREMOVAL, a device has been removed.
                    
                    Debug.WriteLine( "A device has been removed." );
                    
                    //  Find out if it's the device we're communicating with.
                    
                    if ( MyDeviceManagement.DeviceNameMatch( m, myDevicePathName ) ) 
                    { 
                        
                        //  Set MyDeviceDetected False so on the next data-transfer attempt,
                        //  FindTheHid() will be called to look for the device 
                        //  and get a new handle.
                        
                        FrmMy.myDeviceDetected = false; 
                        SetDeviceLed(false);
                    } 
                }                 
            } 
            catch ( Exception ex ) 
            { 
                DisplayException( this.Name, ex ); 
                throw ; 
            } 
        }         
        
        ///  <summary>
        ///  Uses a series of API calls to locate a HID-class device
        ///  by its Vendor ID and Product ID.
        ///  </summary>
        ///          
        ///  <returns>
        ///   True if the device is detected, False if not detected.
        ///  </returns>
        
        private Boolean FindTheHid() 
        {             
            Boolean deviceFound = false; 
            String[] devicePathName = new String[ 128 ];
            String functionName = "";
            Guid hidGuid = Guid.Empty; 
            Int32 memberIndex = 0; 
            Int16 myProductID = 0; 
            Int16 myVendorID = 0; 
            Boolean success = false;            
            
            try 
            { 
                myDeviceDetected = false; 
                
                //  Get the device's Vendor ID and Product ID from the form's text boxes.
                
                GetVendorAndProductIDsFromTextBoxes( ref myVendorID, ref myProductID ); 
                
                //  ***
                //  API function: 'HidD_GetHidGuid
                
                //  Purpose: Retrieves the interface class GUID for the HID class.
                
                //  Accepts: 'A System.Guid object for storing the GUID.
                //  ***
                
                Hid.HidD_GetHidGuid( ref hidGuid );

                functionName = "GetHidGuid"; 
                Debug.WriteLine( MyDebugging.ResultOfAPICall( functionName ) ); 
                Debug.WriteLine( "  GUID for system HIDs: " + hidGuid.ToString() ); 
                
                //  Fill an array with the device path names of all attached HIDs.
                
                deviceFound = MyDeviceManagement.FindDeviceFromGuid( hidGuid, ref devicePathName ); 
                
                //  If there is at least one HID, attempt to read the Vendor ID and Product ID
                //  of each device until there is a match or all devices have been examined.
                
                if ( deviceFound ) 
                {                     
                    memberIndex = 0; 
                    
                    do 
                    { 
                        //  ***
                        //  API function:
                        //  CreateFile
                        
                        //  Purpose:
                        //  Retrieves a handle to a device.
                        
                        //  Accepts:
                        //  A device path name returned by SetupDiGetDeviceInterfaceDetail
                        //  The type of access requested (read/write).
                        //  FILE_SHARE attributes to allow other processes to access the device while this handle is open.
                        //  A Security structure or IntPtr.Zero. 
                        //  A creation disposition value. Use OPEN_EXISTING for devices.
                        //  Flags and attributes for files. Not used for devices.
                        //  Handle to a template file. Not used.
                        
                        //  Returns: a handle without read or write access.
                        //  This enables obtaining information about all HIDs, even system
                        //  keyboards and mice. 
                        //  Separate handles are used for reading and writing.
                        //  ***

                        hidHandle = FileIO.CreateFile(devicePathName[memberIndex], 0, FileIO.FILE_SHARE_READ | FileIO.FILE_SHARE_WRITE, IntPtr.Zero, FileIO.OPEN_EXISTING, 0, 0);

                        functionName = "CreateFile"; 
                        Debug.WriteLine( MyDebugging.ResultOfAPICall( functionName ) ); 
                        Debug.WriteLine( "  Returned handle: " + hidHandle.ToString() ); 
                        
                        if (!hidHandle.IsInvalid)  
                        {                             
                            //  The returned handle is valid, 
                            //  so find out if this is the device we're looking for.
                            
                            //  Set the Size property of DeviceAttributes to the number of bytes in the structure.
                            
                            MyHid.DeviceAttributes.Size = Marshal.SizeOf( MyHid.DeviceAttributes ); 
                            
                            //  ***
                            //  API function:
                            //  HidD_GetAttributes
                            
                            //  Purpose:
                            //  Retrieves a HIDD_ATTRIBUTES structure containing the Vendor ID, 
                            //  Product ID, and Product Version Number for a device.
                            
                            //  Accepts:
                            //  A handle returned by CreateFile.
                            //  A pointer to receive a HIDD_ATTRIBUTES structure.
                            
                            //  Returns:
                            //  True on success, False on failure.
                            //  ***                            
                            
                            success = Hid.HidD_GetAttributes(hidHandle, ref MyHid.DeviceAttributes); 
                            
                            if ( success ) 
                            {                                
                                Debug.WriteLine( "  HIDD_ATTRIBUTES structure filled without error." ); 
                                Debug.WriteLine( "  Structure size: " + MyHid.DeviceAttributes.Size );                                                                                               
                                Debug.WriteLine("  Vendor ID: " + Convert.ToString(MyHid.DeviceAttributes.VendorID, 16));                               
                                Debug.WriteLine("  Product ID: " + Convert.ToString(MyHid.DeviceAttributes.ProductID, 16));                               
                                Debug.WriteLine("  Version Number: " + Convert.ToString(MyHid.DeviceAttributes.VersionNumber, 16)); 
                                
                                //  Find out if the device matches the one we're looking for.
                                
                                if ( ( MyHid.DeviceAttributes.VendorID == myVendorID ) && ( MyHid.DeviceAttributes.ProductID == myProductID ) ) 
                                { 
                                    
                                    Debug.WriteLine( "  My device detected" ); 
                                    
                                    //  Display the information in form's list box.
                                    
                            
                                    myDeviceDetected = true;

                                    //  Save the DevicePathName for OnDeviceChange().
                                    
                                    myDevicePathName = devicePathName[ memberIndex ]; 
                                } 
                                else 
                                {                                     
                                    //  It's not a match, so close the handle.
                                    
                                    myDeviceDetected = false;                                     
                                    hidHandle.Close();                                     
                                }                                 
                            } 
                            else 
                            { 
                                //  There was a problem in retrieving the information.
                                
                                Debug.WriteLine( "  Error in filling HIDD_ATTRIBUTES structure." ); 
                                myDeviceDetected = false; 
                                hidHandle.Close(); 
                            }                             
                        } 
                        
                        //  Keep looking until we find the device or there are no devices left to examine.
                        
                        memberIndex = memberIndex + 1;                         
                    } 
                    while (  ! ( ( myDeviceDetected || ( memberIndex == devicePathName.Length ) ) ) );                     
                }

                SetDeviceLed(myDeviceDetected);

                if ( myDeviceDetected ) 
                {                     
                    //  The device was detected.
                    //  Register to receive notifications if the device is removed or attached.
                    
                    success = MyDeviceManagement.RegisterForDeviceNotifications( myDevicePathName, FrmMy.Handle, hidGuid, ref deviceNotificationHandle ); 
                    
                    Debug.WriteLine( "RegisterForDeviceNotifications = " + success ); 
                    
                    //  Learn the capabilities of the device.
                    
                    MyHid.Capabilities = MyHid.GetDeviceCapabilities( hidHandle ); 
                    
                    if ( success ) 
                    {                         
                        //  Find out if the device is a system mouse or keyboard.
                        
                        hidUsage = MyHid.GetHidUsage( MyHid.Capabilities ); 
                        
                        //  Get the Input report buffer size.
                        
                        
                        //  Get handles to use in requesting Input and Output reports.

                        readHandle = FileIO.CreateFile(myDevicePathName, FileIO.GENERIC_READ, FileIO.FILE_SHARE_READ | FileIO.FILE_SHARE_WRITE, IntPtr.Zero, FileIO.OPEN_EXISTING, FileIO.FILE_FLAG_OVERLAPPED, 0);

                        functionName = "CreateFile, ReadHandle";
                        Debug.WriteLine(MyDebugging.ResultOfAPICall(functionName)); 
                        Debug.WriteLine( "  Returned handle: " + readHandle.ToString() ); 
                        
                        if ( readHandle.IsInvalid ) 
                        {                             
                            exclusiveAccess = true; 
                        } 
                        else 
                        {
                            writeHandle = FileIO.CreateFile(myDevicePathName, FileIO.GENERIC_WRITE, FileIO.FILE_SHARE_READ | FileIO.FILE_SHARE_WRITE, IntPtr.Zero, FileIO.OPEN_EXISTING, 0, 0);

                            functionName = "CreateFile, WriteHandle";
                            Debug.WriteLine(MyDebugging.ResultOfAPICall(functionName)); 
                            Debug.WriteLine( "  Returned handle: " + writeHandle.ToString() ); 
                            
                            //  Flush any waiting reports in the input buffer. (optional)
                            
                            MyHid.FlushQueue( readHandle );                             
                        } 
                    } 
                } 
                else 
                { 
                    Debug.WriteLine( " Device not found." );                     
                }                 
                return myDeviceDetected;                 
            } 
            catch ( Exception ex ) 
            { 
                DisplayException( this.Name, ex ); 
                throw ; 
            } 
        }         
        
     
                
        ///  <summary>
        ///  Search for a specific device.
        ///  </summary>
        
        private void cmdFindDevice_Click( System.Object sender, System.EventArgs e ) 
        {            
            try 
            {
                myDeviceDetected = FindTheHid();

                if (myDeviceDetected)
                {

                    rxThread = new Thread(new ThreadStart(this.ReceiveThread));
                    rxThread.Name = "CommBaseRx";
                    rxThread.Priority = ThreadPriority.Normal;
                    rxThread.IsBackground = true;
                    rxThread.Start();

                    ctrlInputGroupBox.Enabled = true;

                    SendCommand(0x01, 00);
                    Thread.Sleep(10);
                    UpdateLEDToDevice();
                    Thread.Sleep(10);
                    UpdateADCToDevice(adcOnCheckBox.Checked);
                }
            } 
            catch ( Exception ex ) 
            { 
                DisplayException( this.Name, ex ); 
                throw ; 
            }             
        }


        private void ReceiveThread()
        {
            String byteValue = null;
            Int32 count = 0;
            Byte[] inputReportBuffer = null;
            Byte[] outputReportBuffer = null;
            Boolean success = false; 

            for (; ; )
            {
                if ( hidHandle != null  && !hidHandle.IsInvalid)
                {

                    //  Read a report using interrupt transfers.                
                    //  To enable reading a report without blocking the main thread, this
                    //  application uses an asynchronous delegate.
                    inputReportBuffer = new Byte[MyHid.Capabilities.InputReportByteLength]; 

                    //IAsyncResult ar = null;
                    Hid.InputReportViaInterruptTransfer myInputReport = new Hid.InputReportViaInterruptTransfer();
                    myInputReport.Read(hidHandle, readHandle, writeHandle, ref myDeviceDetected, ref inputReportBuffer, ref success);

                    if (success)
                    {
                        string str = string.Format("Got bytes {0} {1} {2}", inputReportBuffer[1], inputReportBuffer[2],inputReportBuffer[3]);
                        System.Console.WriteLine(str);
                        ushort wValue = (ushort)(1 * ( ((int)(inputReportBuffer[2] & 0x03) << 8) + (int)inputReportBuffer[3]) );

                        switch (inputReportBuffer[1])
                        {
                            case 0x02:
                                if (wValue < 0)
                                {
                                    wValue = 0;
                                }
                                if (wValue > 1023)
                                {
                                    wValue = 1023;
                                }
                                SetAdcIndicator(wValue);
                                break;
                            case 0x10:
                                SetPortA(inputReportBuffer[2]);
                                break;
                            case 0x11:
                                SetPortB(inputReportBuffer[2]);
                                break;
                            case 0x12:
                                SetPortC(inputReportBuffer[2]);
                                break;
                            case 0x13:
                                SetPortD(inputReportBuffer[2]);
                                break;
                        }
                    }
                }
                Thread.Sleep(5);
            }
        }
        
        ///  <summary>
        ///  Called if the user changes the Vendor ID or Product ID in the text box.
        ///  </summary>
          
        private void DeviceHasChanged() 
        {             
            try 
            { 
                //  If a device was previously detected, stop receiving notifications about it.
                
                if ( myDeviceDetected ) 
                { 
                    MyDeviceManagement.StopReceivingDeviceNotifications( deviceNotificationHandle ); 
                } 
                
                //  Search for the device the next time FindTheHid is called.
                
                myDeviceDetected = false;                 
            } 
            catch ( Exception ex ) 
            { 
                DisplayException( this.Name, ex ); 
                throw ; 
            } 
        }         
        
        
        ///  <summary>
        ///  Sends an Output report, then retrieves an Input report.
        ///  Assumes report ID = 0 for both reports.
        ///  </summary>
        
        
        ///  <summary>
        ///  Perform shutdown operations.
        ///  </summary>
        
        private void frmMain_Closed( System.Object eventSender, System.EventArgs eventArgs ) 
        {             
            try 
            { 
                Shutdown();                 
            } 
            catch ( Exception ex ) 
            { 
                DisplayException( this.Name, ex ); 
                throw ; 
            } 
        }         
        
        ///  <summary>
        ///  Perform startup operations.
        ///  </summary>
        
        private void frmMain_Load( System.Object eventSender, System.EventArgs eventArgs ) 
        {             
            try 
            { 
                FrmMy = this; 
                Startup();                 
            } 
            catch ( Exception ex ) 
            { 
                DisplayException( this.Name, ex ); 
                throw ; 
            }             
        }         
        
        ///  <summary>
        ///  Retrieves Input report data and status information.
        ///  This routine is called automatically when myInputReport.Read
        ///  returns. Calls several marshaling routines to access the main form.
        ///  </summary>
        ///  
        ///  <param name="ar"> an object containing status information about 
        ///  the asynchronous operation. </param>
        
        private void GetInputReportData( IAsyncResult ar ) 
        {             
            String byteValue = null; 
            Int32 count = 0; 
            Byte[] inputReportBuffer = null; 
            Boolean success = false; 
            
            try 
            { 
                // Define a delegate using the IAsyncResult object.
                
                ReadInputReportDelegate deleg = ( ( ReadInputReportDelegate )( ar.AsyncState ) ); 
                
                //  Get the IAsyncResult object and the values of other paramaters that the
                //  BeginInvoke method passed ByRef.
                
                deleg.EndInvoke( ref myDeviceDetected, ref inputReportBuffer, ref success, ar ); 
                
                //  Display the received report data in the form's list box.
                
                if ( ( ar.IsCompleted && success ) ) 
                { 
                    
                    for ( count=0; count <= inputReportBuffer.Length -1 ; count++ ) 
                    {                         
                        //  Display bytes as 2-character Hex strings.
                        
                        byteValue = String.Format( "{0:X2} ", inputReportBuffer[ count ] ); 
                    }                     
                } 
                else 
                { 
                    Debug.Write( "The attempt to read an Input report has failed" ); 
                } 
                
            } 
            catch ( Exception ex ) 
            { 
                DisplayException( this.Name, ex ); 
                throw ; 
            }             
        }         
        
        ///  <summary>
        ///  Retrieves a Vendor ID and Product ID in hexadecimal 
        ///  from the form's text boxes and converts the text to Int16s.
        ///  </summary>
        ///  
        ///  <param name="myVendorID"> the Vendor ID as a Int16.</param>
        ///  <param name="myProductID"> the Product ID as a Int16. </param>
        
        private void GetVendorAndProductIDsFromTextBoxes( ref Int16 myVendorID, ref Int16 myProductID ) 
        {             
            try 
            { 
                myVendorID = Convert.ToInt16( Conversion.Val( "&h" + txtVendorID.Text ) ); 
                myProductID = Convert.ToInt16( Conversion.Val( "&h" + txtProductID.Text ) );                 
            } 
            catch ( Exception ex ) 
            { 
                DisplayException( this.Name, ex ); 
                throw ; 
            }             
        }         
        
        private void SendCommand(byte cmd, byte param1)
        {
            Byte[] outputReportBuffer = null;
            Boolean success = false;
            outputReportBuffer = new Byte[MyHid.Capabilities.OutputReportByteLength];

            //  Store the report ID in the first byte of the buffer:
            outputReportBuffer[0] = 0;

            outputReportBuffer[1] = cmd;
            outputReportBuffer[2] = param1;

            string strOut = string.Format("SendCommand {0:X2} {1:X2}", outputReportBuffer[1], outputReportBuffer[2]);
            System.Console.WriteLine(strOut);
            Hid.OutputReportViaInterruptTransfer myOutputReport = new Hid.OutputReportViaInterruptTransfer();
            success = myOutputReport.Write(outputReportBuffer, writeHandle);

            if (success)
            {
                System.Console.WriteLine(string.Format("Send command {0:X2} value {1:X2}", cmd, param1));
            }
        }


        private void SetAdcIndicator(ushort wValue)
        {
            if (this.InvokeRequired)
            {
                BeginInvoke(new MethodInvoker(delegate() { SetAdcIndicator(wValue); }));
            }
            else
            {
                adcIndicator.Value = wValue;
            }
        }

        private string ByteToBinString(byte btValue)
        {
            int i;
            string outStr = "0b ";
            for ( i=0;i<8;i++ )
            {
                if (btValue >= 128)
                    outStr += "1";
                else
                    outStr += "0";
                btValue <<= 1;
            }
            return outStr;
        }

        private void SetPortA(byte btValue)
        {
            if (this.InvokeRequired)
            {
                BeginInvoke(new MethodInvoker(delegate() { SetPortA(btValue); }));
            }
            else
            {
                portATextBox.Text = ByteToBinString(btValue);
            }
        }

        private void SetPortB(byte btValue)
        {
            if (this.InvokeRequired)
            {
                BeginInvoke(new MethodInvoker(delegate() { SetPortB(btValue); }));
            }
            else
            {
                portBTextBox.Text = ByteToBinString(btValue);
            }
        }
        private void SetPortC(byte btValue)
        {
            if (this.InvokeRequired)
            {
                BeginInvoke(new MethodInvoker(delegate() { SetPortC(btValue); }));
            }
            else
            {
                portCTextBox.Text = ByteToBinString(btValue);
            }
        }

        private void SetPortD(byte btValue)
        {
            if (this.InvokeRequired)
            {
                BeginInvoke(new MethodInvoker(delegate() { SetPortD(btValue); }));
            }
            else
            {
                portDTextBox.Text = ByteToBinString(btValue);
            }
        }

   
        
        ///  <summary>
        ///  Perform actions that must execute when the program ends.
        ///  </summary>
        
        private void Shutdown() 
        {             
            try 
            { 
                //  Close open handles to the device.
                
                if ( !( hidHandle == null ) ) 
                { 
                    if ( !( hidHandle.IsInvalid ) ) 
                    { 
                        hidHandle.Close(); 
                    } 
                } 
                
                if ( !( readHandle == null ) ) 
                { 
                    if ( !( readHandle.IsInvalid ) ) 
                    { 
                        readHandle.Close(); 
                    } 
                } 
                
                if ( !( writeHandle == null ) ) 
                { 
                    if ( !( writeHandle.IsInvalid ) ) 
                    { 
                        writeHandle.Close(); 
                    } 
                } 
                
                //  Stop receiving notifications.
                
                MyDeviceManagement.StopReceivingDeviceNotifications( deviceNotificationHandle );                 
            } 
            catch ( Exception ex ) 
            { 
                DisplayException( this.Name, ex ); 
                throw ; 
            }             
        } 
                
        ///  <summary>
        ///  Perform actions that must execute when the program starts.
        ///  </summary>
        
        private void Startup() 
        {            
            try 
            { 
                MyHid = new Hid(); 
                
                //  Default USB Vendor ID and Product ID:
                
                txtVendorID.Text = "0925"; 
                txtProductID.Text = "7001";    
             
                // disable inputs
                ctrlInputGroupBox.Enabled = false;
            } 
            catch ( Exception ex ) 
            { 
                DisplayException( this.Name, ex ); 
                throw ; 
            }             
        }         
                
        ///  <summary>
        ///  The Product ID has changed in the text box. Call a routine to handle it.
        ///  </summary>
        
        private void txtProductID_TextChanged( System.Object sender, System.EventArgs e ) 
        {            
            try 
            { 
                DeviceHasChanged();                 
            } 
            catch ( Exception ex ) 
            { 
                DisplayException( this.Name, ex ); 
                throw ; 
            } 
        } 
                
        ///  <summary>
        ///  The Vendor ID has changed in the text box. Call a routine to handle it.
        ///  </summary>
        
        private void txtVendorID_TextChanged( System.Object sender, System.EventArgs e ) 
        {            
            try 
            { 
                DeviceHasChanged();                 
            } 
            catch ( Exception ex ) 
            { 
                DisplayException( this.Name, ex ); 
                throw ; 
            }             
        }         
        
        ///  <summary>
        ///  Finalize method.
        ///  </summary>
        
        ~FrmMain() 
        { 
        } 
                
        ///  <summary>
        ///   Overrides WndProc to enable checking for and handling WM_DEVICECHANGE messages.
        ///  </summary>
        ///  
        ///  <param name="m"> a Windows Message </param>
        
        protected override void WndProc( ref Message m ) 
        {            
            try 
            { 
                //  The OnDeviceChange routine processes WM_DEVICECHANGE messages.
                
                if ( m.Msg == DeviceManagement.WM_DEVICECHANGE ) 
                { 
                    OnDeviceChange( m ); 
                } 
                
                //  Let the base form process the message.
                
                base.WndProc( ref m );                 
            } 
            catch ( Exception ex ) 
            { 
                DisplayException( this.Name, ex ); 
                throw ; 
            }             
        }         
        
        ///  <summary>
        ///  Provides a central mechanism for exception handling.
        ///  Displays a message box that describes the exception.
        ///  </summary>
        ///  
        ///  <param name="moduleName"> the module where the exception occurred. </param>
        ///  <param name="e"> the exception </param>
        
        internal static void DisplayException( String moduleName, Exception e ) 
        {             
            String message = null; 
            String caption = null; 
            
            //  Create an error message.
            
            message = "Exception: " + e.Message + ControlChars.CrLf + "Module: " + moduleName + ControlChars.CrLf + "Method: " + e.TargetSite.Name; 
            
            caption = "Unexpected Exception"; 
            
            MessageBox.Show( message, caption, MessageBoxButtons.OK ); 
            Debug.Write( message );             
        } 
                
        [STAThread]
        internal static void Main() { Application.Run( new FrmMain() ); }       
        private static FrmMain transDefaultFormFrmMain = null;
        internal static FrmMain TransDefaultFormFrmMain
        { 
        	get
        	{ 
        		if (transDefaultFormFrmMain == null)
        		{
        			transDefaultFormFrmMain = new FrmMain();
        		}
        		return transDefaultFormFrmMain;
        	} 
        }


        private void UpdateLEDToDevice()
        {
            byte param = 0;
            if (led0CheckBox.Checked) param |= 0x01;
            if (led1CheckBox.Checked) param |= 0x02;
            if (led2CheckBox.Checked) param |= 0x04;
            if (led3CheckBox.Checked) param |= 0x08;
            if (led4CheckBox.Checked) param |= 0x10;
            if (led5CheckBox.Checked) param |= 0x20;
            if (led6CheckBox.Checked) param |= 0x40;
            if (led7CheckBox.Checked) param |= 0x80;
            SendCommand(0x03, param);
        }


        private void UpdateADCToDevice( bool adcOnOff )
        {
            if ( adcOnOff )
                SendCommand(0x04, 0x00);
            else
                SendCommand(0x05, 0x00);
        }

        private void ledCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            UpdateLEDToDevice();
        }

        private void adcOnCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            UpdateADCToDevice( adcOnCheckBox.Checked );
        }

        private void adcIndicator_Click(object sender, EventArgs e)
        {

        }

        private void devicePresentPB_Click(object sender, EventArgs e)
        {

        }

    }      
} 
