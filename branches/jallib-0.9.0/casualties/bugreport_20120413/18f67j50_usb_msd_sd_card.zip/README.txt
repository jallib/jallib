See the following. print_byte_hex for sd_sector_buffer_high[step2] results in a change in msd_tx_buffer[0x2B]

if step2 == 0x2B then
   ;serial_data = "|"
   print_byte_hex(serial_data,msd_tx_buffer[0x2B])

   -- If I change step2 to constant 0xB2 or to word(step2), it works.
   -- However, with step2 as it is, msd_tx_buffer[0x2B] will be wrong in next print_byte_hex statement.
   -- try either way...
   ;print_byte_hex(serial_data,storage_sector_buffer[_usb_msd_step64 + step2 ])
   var byte address = byte((_usb_msd_step64 + step2) / 2)
   print_byte_hex(serial_data, sd_sector_buffer_high[address])
   
   print_byte_hex(serial_data,msd_tx_buffer[0x2B])
   serial_data = "|"
end if