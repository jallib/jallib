I am receiving some weird behavior with 2.4q2. The program works at initial power on after the power has been off for some time. After some use, or after a short power off, I receive unexpected results causing usb_msd to fail. It will not work again untill a long power off occurs. I have the same issue with and without -no-variable-reuse

As shown on fail.php, the hex data 0055 should be 5555. This serial data is sent from usb_msd_testing.jal at line 1241/1242 in "for 13 using index loop". The data highlighted is for the first loop only (index = 0). As you can see, I am sending the same data twice when index = 0 via msd_tx_buffer[index] and msd_tx_buffer[0].

   -- send csw (31 bytes)
   msd_tx_buffer[0] = 0x55
   msd_tx_buffer[1] = 0x53
   msd_tx_buffer[2] = 0x42
   msd_tx_buffer[3] = 0x53
   msd_tx_buffer[4] = _usb_msd_cbw_signature[0]
   msd_tx_buffer[5] = _usb_msd_cbw_signature[1]
   msd_tx_buffer[6] = _usb_msd_cbw_signature[2]
   msd_tx_buffer[7] = _usb_msd_cbw_signature[3]
   msd_tx_buffer[8] = _usb_msd_cbw_tag[0]
   msd_tx_buffer[9] = _usb_msd_cbw_tag[1]
   msd_tx_buffer[10] = _usb_msd_cbw_tag[2]
   msd_tx_buffer[11] = _usb_msd_cbw_tag[3]
   msd_tx_buffer[12] = usb_msd_csw_status

serial_data = "%"
print_dword_hex(serial_data, usb_msd_cbw_tag)
serial_data = "%"
print_string(serial_data, msd_tx_buffer)
serial_data = "%"

   var byte index = 0
   for 13 using index loop
      print_byte_hex(serial_data,msd_tx_buffer[index])
      print_byte_hex(serial_data,msd_tx_buffer[0])
   end loop
serial_data = "%"







4758 data accesses checked, 0 errors
498 skips checked, 0 errors
Hardware stack depth INFINITE
Compiler CommandLine:  d:\dev\jalv2\compiler\jalv2.exe -s "d:\dev\jalv2\lib" -no-variable-reuse -hex "d:\dev\jalv2\sample\temp.hex" "D:\dev\jalv2\sample\18f67j50_usb_msd_sd_card.jal"  

Errors :0       Warnings :0
Code   :23278/131064    Data:1129/3904  Hardware Stack : 0/100  Software Stack :2112
