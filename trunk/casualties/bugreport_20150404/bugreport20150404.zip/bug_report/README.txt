jal jalv24q2 (compiled Jan 23 2014) and previous versions

See 18f4550_temperature_max6675_bugreport.jal. 

Prints hex 12BB instead of AABB for an 2 byte array difined "AT" a word. I can't assign a value to the high byte.



WORKAROUND/FIX:
To fix the program, just rename variable _temperature to my_temp. The compiler does not like the underscore in the variable name.

ASM file diff shows no +1 for variable _temperature

- movwf v__temperature,v__access

+ movwf v_my_temp+1,v__access
