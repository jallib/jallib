jal jalv24q2 (compiled Jan 23 2014)

See 18f4550_temperature_max6675_bugreport.jal. 

Prints hex 12BB instead of AABB for an 2 byte array difined "AT" a word. I can't assign a value to the high byte.