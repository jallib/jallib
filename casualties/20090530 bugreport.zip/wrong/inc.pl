use strict;

print"\"";

while (<>) {
   if (/.svn/) { next; }  
   s#/cygdrive/c#c:#;
   s#/#\\#g;
   chomp;
   print "$_;";
}
print"\"";
